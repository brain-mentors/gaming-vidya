import javax.swing.JFrame;

// Create Frame
// Ctrl + Shift + O
// class name - PascalCase
// method name - camelCase
public class GameFrame extends JFrame {

	public static void main(String[] args) {
		
		// create the object of GameFrame
		GameFrame obj = new GameFrame();
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		obj.setSize(1400,900);
		obj.setResizable(false);
		obj.setTitle("Game-2023");
		Board board = new Board();
		obj.add(board);
		obj.setLocationRelativeTo(null); // center of the screen
		obj.setVisible(true);
		

	}

}
