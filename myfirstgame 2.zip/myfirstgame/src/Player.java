import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Player {
	int x;
	int y;
	int w;
	int h;
	// Gif
	ImageIcon image;
	int speed; // 0
	void move() {
		x = x + speed;
	}
	Player(){
		w = 200;
		h = 200;
		x = 100;
		y = 900 - 120 - h;
		
		image = new ImageIcon(Player.class.getResource("player.gif"));
	}
	
	public void draw(Graphics g) {
		g.drawImage(image.getImage(), x,y,w,h, null);
	}
	
	
}
