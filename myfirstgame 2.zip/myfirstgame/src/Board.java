import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;
// load the image and then paint the image
public class Board extends JPanel {
	BufferedImage bg;
	Timer timer;
	Player player  = new Player();
	Enemy enemy = new Enemy();
	
	// Constructor
	Board(){
		setFocusable(true);
		
		loadImage();
		bindEvent();
		timer = new Timer(50,(e)->repaint());
		timer.start();
		// repaint call paintComponent
	}
	
	boolean isCollide() {
		int xDistance =  Math.abs(player.x - enemy.x);
		int yDistance = Math.abs(player.y - enemy.y);
		return xDistance<=(player.w-150) && yDistance<=player.h-50;
	}
	
	 void bindEvent() {
		this.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				player.speed = 0;
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
					player.speed = 5;
				}
				else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
					player.speed=-5;
				}
				
				
			}
		});
	}
	
	// now we want to paint the image on board
	public void paintComponent(Graphics pen){
		super.paintComponent(pen); // clear the panel
		//pen.drawImage(bg, x,y, w, h, null);
		pen.drawImage(bg,0,0,1400,900, null); // print background image
		// print player
		player.draw(pen);
		enemy.draw(pen);
		player.move();
		enemy.move();
		if(isCollide()) {
			System.out.println("Game Over.....");
			pen.setColor(Color.RED);
			pen.setFont(new Font("times", Font.BOLD,50));
			pen.drawString("Game Over", 500, 500);
			timer.stop();
		}
		
	}
	// Now Image is in the Memory
	void loadImage(){
		// Read Image from Disk and Place it on RAM.
		
		try {
			bg = ImageIO.read(Board.class.getResource("bg.jpeg"));
		} catch (IOException e) {
			System.out.println("Some Problem in Background Image");
			// TODO Auto-generated catch block
			e.printStackTrace(); // print stack trace of exception
		}
	}
}
