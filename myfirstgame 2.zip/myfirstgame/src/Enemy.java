import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Enemy {
	int x;
	int y;
	int w;
	int h;
	int speed = 5;
	// Gif
	ImageIcon image;
	
	void move() {
		if(y>900) {
			y = 0;
		}
		y = y + speed;
	}
	
	Enemy(){
		w = 200;
		h = 200;
		x = 600;
		y = 20;
		
		image = new ImageIcon(Enemy.class.getResource("spider.gif"));
	}
	
	public void draw(Graphics g) {
		g.drawImage(image.getImage(), x,y,w,h, null);
	}
}
